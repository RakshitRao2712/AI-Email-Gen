package com.email.EmailWriter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmailWriterApplicationTests {

	@Test
	void contextLoads() {
	}

}
